**Note: this is the technical bug tracker, please use other platforms for getting support and starting a (non technical) discussion. See the [getting help page](https://gekko.wizb.it/docs/introduction/getting-help.html) for details.**

**I'm submitting a ...**
[ ] bug report
[ ] question about the decisions made in the repository

**Action taken** (what you did)


**Expected result** (what you hoped would happen)


**Actual result** (unexpected outcome)


**Other information** (e.g. detailed explanation, stacktraces, related issues, suggestions how to fix, links for us to have context, eg. stackoverflow, etc)

