const sticky = require('./sticky');

module.exports = {
  sticky
}