const trailingStop = require('./trailingStop');

module.exports = { trailingStop };